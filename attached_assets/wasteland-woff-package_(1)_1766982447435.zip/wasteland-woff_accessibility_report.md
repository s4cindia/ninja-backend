# Accessibility Report

**File:** wasteland-woff.epub
**Job ID:** f308389a-e20e-4713-9c2d-79cd9830eadb
**Generated:** 2025-12-29T04:26:35.687Z

## Summary

| Metric | Value |
|--------|-------|
| Original Issues | 14 |
| Fixed Issues | 3 |
| Remaining Issues | 11 |
| Fix Rate | 21% |

## WCAG Compliance

| Criterion | Name | Status | Issues | Fixed |
|-----------|------|--------|--------|-------|
| 1.3.1 | Info and Relationships | ❌ fail | 2 | 0 |
| EPUB Accessibility 1.0 | WCAG EPUB Accessibility 1.0 | ✅ pass | 3 | 3 |

## All Issues (14)

| Code | Severity | Status | Type | Location | WCAG |
|------|----------|--------|------|----------|------|
| METADATA-ACCESSMODE | critical | ❌ pending | manual | EPUB/wasteland.opf | - |
| METADATA-ACCESSMODESUFFICIENT | critical | ❌ pending | manual | EPUB/wasteland.opf | - |
| METADATA-ACCESSIBILITYFEATURE | critical | ❌ pending | manual | EPUB/wasteland.opf | - |
| METADATA-ACCESSIBILITYHAZARD | critical | ❌ pending | manual | EPUB/wasteland.opf | - |
| METADATA-ACCESSIBILITYSUMMARY | critical | ❌ pending | manual | EPUB/wasteland.opf | - |
| COLOR-CONTRAST | critical | ❌ pending | manual | wasteland-content.xhtml | - |
| EPUB-TYPE-HAS-MATCHING-ROLE | critical | ❌ pending | manual | wasteland-content.xhtml | - |
| EPUB-TYPE-HAS-MATCHING-ROLE | critical | ❌ pending | manual | wasteland-nav.xhtml | - |
| LANDMARK-UNIQUE | critical | ❌ pending | manual | wasteland-nav.xhtml | - |
| EPUB-META-002 | moderate | ✅ fixed | auto |  | EPUB Accessibility 1.0 |
| EPUB-META-003 | minor | ✅ fixed | auto |  | EPUB Accessibility 1.0 |
| EPUB-META-004 | moderate | ✅ fixed | auto |  | EPUB Accessibility 1.0 |
| EPUB-STRUCT-004 | minor | ❌ pending | auto | EPUB/wasteland-content.xhtml | 1.3.1 |
| EPUB-STRUCT-004 | minor | ❌ pending | auto | EPUB/wasteland-nav.xhtml | 1.3.1 |

### Issue Details

#### ❌ METADATA-ACCESSMODE
- **Message:** Publications must declare the 'schema:accessMode' metadata
- **Severity:** critical
- **Location:** EPUB/wasteland.opf
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ METADATA-ACCESSMODESUFFICIENT
- **Message:** Publications must declare the 'schema:accessModeSufficient' metadata
- **Severity:** critical
- **Location:** EPUB/wasteland.opf
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ METADATA-ACCESSIBILITYFEATURE
- **Message:** Publications must declare the 'schema:accessibilityFeature' metadata
- **Severity:** critical
- **Location:** EPUB/wasteland.opf
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ METADATA-ACCESSIBILITYHAZARD
- **Message:** Publications must declare the 'schema:accessibilityHazard' metadata
- **Severity:** critical
- **Location:** EPUB/wasteland.opf
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ METADATA-ACCESSIBILITYSUMMARY
- **Message:** Publications must declare the 'schema:accessibilitySummary' metadata
- **Severity:** critical
- **Location:** EPUB/wasteland.opf
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ COLOR-CONTRAST
- **Message:** Element has insufficient color contrast of 3.92 (foreground color: #808080, background color: #fffff5, font size: 10.8pt (14.4px), font weight: normal). Expected contrast ratio of 4.5:1
- **Severity:** critical
- **Location:** wasteland-content.xhtml
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ EPUB-TYPE-HAS-MATCHING-ROLE
- **Message:** Element has no ARIA role matching its epub:type
- **Severity:** critical
- **Location:** wasteland-content.xhtml
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ EPUB-TYPE-HAS-MATCHING-ROLE
- **Message:** Element has no ARIA role matching its epub:type
- **Severity:** critical
- **Location:** wasteland-nav.xhtml
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ❌ LANDMARK-UNIQUE
- **Message:** The landmark must have a unique aria-label, aria-labelledby, or title to make landmarks distinguishable
- **Severity:** critical
- **Location:** wasteland-nav.xhtml
- **Source:** ace
- **Type:** Manual fix required
- **Status:** pending

#### ✅ EPUB-META-002
- **Message:** Missing accessibility feature metadata
- **Severity:** moderate
- **Location:** 
- **Source:** js-auditor
- **Type:** Auto-fixable
- **Status:** fixed
- **WCAG Criteria:** EPUB Accessibility 1.0

#### ✅ EPUB-META-003
- **Message:** Missing accessibility summary
- **Severity:** minor
- **Location:** 
- **Source:** js-auditor
- **Type:** Auto-fixable
- **Status:** fixed
- **WCAG Criteria:** EPUB Accessibility 1.0

#### ✅ EPUB-META-004
- **Message:** Missing access mode metadata
- **Severity:** moderate
- **Location:** 
- **Source:** js-auditor
- **Type:** Auto-fixable
- **Status:** fixed
- **WCAG Criteria:** EPUB Accessibility 1.0

#### ❌ EPUB-STRUCT-004
- **Message:** Missing main landmark
- **Severity:** minor
- **Location:** EPUB/wasteland-content.xhtml
- **Source:** js-auditor
- **Type:** Auto-fixable
- **Status:** pending
- **WCAG Criteria:** 1.3.1

#### ❌ EPUB-STRUCT-004
- **Message:** Missing main landmark
- **Severity:** minor
- **Location:** EPUB/wasteland-nav.xhtml
- **Source:** js-auditor
- **Type:** Auto-fixable
- **Status:** pending
- **WCAG Criteria:** 1.3.1

## Applied Fixes (5)

- **EPUB-META-002** (metadata): Added 4 accessibility metadata elements [WCAG EPUB Accessibility 1.0]
- **EPUB-META-004** (metadata): Added 2 access mode elements [WCAG EPUB Accessibility 1.0]
- **EPUB-META-003** (metadata): Added accessibility summary [WCAG EPUB Accessibility 1.0]
- **EPUB-STRUCT-004** (structure): Added role="main" to <section> [WCAG 1.3.1]
- **EPUB-STRUCT-004** (structure): ARIA landmarks already present or not applicable [WCAG 1.3.1]

## Issue Resolutions

| Code | Location | Original | Final | Resolution Type |
|------|----------|----------|-------|----------------|
| METADATA-ACCESSMODE | EPUB/wasteland.opf | pending | pending | not-fixed |
| METADATA-ACCESSMODESUFFICIENT | EPUB/wasteland.opf | pending | pending | not-fixed |
| METADATA-ACCESSIBILITYFEATURE | EPUB/wasteland.opf | pending | pending | not-fixed |
| METADATA-ACCESSIBILITYHAZARD | EPUB/wasteland.opf | pending | pending | not-fixed |
| METADATA-ACCESSIBILITYSUMMARY | EPUB/wasteland.opf | pending | pending | not-fixed |
| COLOR-CONTRAST | wasteland-content.xhtml | pending | pending | not-fixed |
| EPUB-TYPE-HAS-MATCHING-ROLE | wasteland-content.xhtml | pending | pending | not-fixed |
| EPUB-TYPE-HAS-MATCHING-ROLE | wasteland-nav.xhtml | pending | pending | not-fixed |
| LANDMARK-UNIQUE | wasteland-nav.xhtml | pending | pending | not-fixed |
| EPUB-META-002 |  | pending | fixed | auto-remediated |
| EPUB-META-003 |  | pending | fixed | auto-remediated |
| EPUB-META-004 |  | pending | fixed | auto-remediated |
| EPUB-STRUCT-004 | EPUB/wasteland-content.xhtml | pending | pending | not-fixed |
| EPUB-STRUCT-004 | EPUB/wasteland-nav.xhtml | pending | pending | not-fixed |
