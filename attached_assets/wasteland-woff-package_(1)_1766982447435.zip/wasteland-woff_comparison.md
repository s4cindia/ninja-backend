# EPUB Comparison Report

**Original:** wasteland-woff.epub
**Remediated:** wasteland-woff_remediated.epub
**Generated:** 2025-12-29T04:26:35.458Z

## Summary

| Metric | Count |
|--------|-------|
| Total Files | 13 |
| Modified Files | 3 |
| Added Files | 0 |
| Removed Files | 0 |
| Total Changes | 5 |

## Modifications

### add_aria_landmarks
- **Category:** structure
- **Description:** Added 1 ARIA landmark(s)
- **WCAG Criterion:** 1.3.1
- **File:** EPUB/wasteland-content.xhtml

### add_aria_landmarks
- **Category:** structure
- **Description:** Added 1 ARIA landmark(s)
- **WCAG Criterion:** 1.3.1
- **File:** EPUB/wasteland-nav.xhtml

### add_accessibility_metadata
- **Category:** accessibility
- **Description:** Added accessibility feature metadata
- **WCAG Criterion:** EPUB Accessibility 1.0
- **File:** EPUB/wasteland.opf

### add_accessibility_summary
- **Category:** accessibility
- **Description:** Added accessibility summary
- **File:** EPUB/wasteland.opf

### add_access_modes
- **Category:** accessibility
- **Description:** Added access mode metadata
- **File:** EPUB/wasteland.opf

